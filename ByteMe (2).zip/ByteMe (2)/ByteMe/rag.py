"""Grounded follow-up Q&A over stored meeting transcripts."""
from typing import Any, Dict, List

import llm
import store


def answer_question(question: str) -> Dict[str, Any]:
    sources = store.retrieve_passages(question)
    if not sources:
        return {
            "answer": "I couldn't find this in the stored meeting transcripts.",
            "sources": [],
        }

    context = "\n\n".join(
        f"[Source {i}: meeting {source['transcript_id']}, excerpt {source['chunk']}]\n{source['passage']}"
        for i, source in enumerate(sources, start=1)
    )
    prompt = (
        "Answer the user's question using only the meeting excerpts below. "
        "If the excerpts do not contain the answer, clearly say so. Do not infer or invent facts. "
        "Keep the answer concise and cite the supporting source numbers like [Source 1].\n\n"
        f"Meeting excerpts:\n{context}\n\nQuestion: {question}"
    )
    try:
        answer = llm.chat([
            {"role": "system", "content": "You provide accurate, grounded answers about meeting records."},
            {"role": "user", "content": prompt},
        ])
    except RuntimeError:
        # Retrieval remains useful during local demos even when no LLM key is configured.
        answer = "Relevant meeting records:\n\n" + "\n\n".join(
            f"[Source {index}] {source['passage']}" for index, source in enumerate(sources, start=1)
        )
    return {
        "answer": answer,
        "sources": [
            {
                "source": index,
                "transcript_id": source["transcript_id"],
                "meta": source["meta"],
                "excerpt": source["passage"],
            }
            for index, source in enumerate(sources, start=1)
        ],
    }
