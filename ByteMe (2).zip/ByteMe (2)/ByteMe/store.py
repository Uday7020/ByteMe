"""
Simple file-based store for transcripts, summaries, and action items.
This is a small persistence layer for the prototype. It stores JSON files under ./data/.
Replace or extend with a DB or vector store for production.
"""
import os
import json
import re
import uuid
import math
import hashlib
from typing import Dict, Any, List

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR, exist_ok=True)

TRANSCRIPT_DIR = os.path.join(DATA_DIR, "transcripts")
SUMMARY_DIR = os.path.join(DATA_DIR, "summaries")
ACTIONS_DIR = os.path.join(DATA_DIR, "actions")
VECTOR_INDEX_PATH = os.path.join(DATA_DIR, "meeting_vectors.json")

for d in (TRANSCRIPT_DIR, SUMMARY_DIR, ACTIONS_DIR):
    os.makedirs(d, exist_ok=True)


def _write_json(path: str, obj: Any):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)


def _read_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _load_vector_index() -> List[Dict[str, Any]]:
    """Load the persisted, lightweight meeting vector index."""
    if not os.path.exists(VECTOR_INDEX_PATH):
        return []
    try:
        records = _read_json(VECTOR_INDEX_PATH)
        return records if isinstance(records, list) else []
    except (OSError, ValueError):
        return []


def _save_vector_index(records: List[Dict[str, Any]]) -> None:
    _write_json(VECTOR_INDEX_PATH, records)


def _embed(text: str, dimensions: int = 384) -> List[float]:
    """Create a deterministic local text embedding without network/model downloads.

    The hashed word and word-pair representation is persisted with each record so a
    query can be compared using cosine similarity even after the server restarts.
    It deliberately has no cloud dependency; swap this function for a hosted or
    sentence-transformer embedding model when higher semantic recall is needed.
    """
    tokens = re.findall(r"[a-z0-9]+", text.lower())
    vector = [0.0] * dimensions
    features = tokens + [f"{left}_{right}" for left, right in zip(tokens, tokens[1:])]
    for feature in features:
        slot = int(hashlib.sha256(feature.encode("utf-8")).hexdigest(), 16) % dimensions
        vector[slot] += 1.0
    magnitude = math.sqrt(sum(value * value for value in vector))
    return [value / magnitude for value in vector] if magnitude else vector


def _chunk_text(text: str, chunk_size: int = 900) -> List[str]:
    return [text[start:start + chunk_size] for start in range(0, len(text), chunk_size) if text[start:start + chunk_size].strip()]


def _index_content(transcript_id: str, content_type: str, text: str, meta: Dict[str, Any] = None) -> None:
    """Persist embeddings for a transcript-related record, replacing stale chunks."""
    records = [record for record in _load_vector_index()
               if not (record.get("transcript_id") == transcript_id and record.get("content_type") == content_type)]
    for chunk_number, chunk in enumerate(_chunk_text(text), start=1):
        records.append({
            "id": f"{transcript_id}:{content_type}:{chunk_number}",
            "transcript_id": transcript_id,
            "content_type": content_type,
            "chunk": chunk_number,
            "text": chunk,
            "meta": meta or {},
            "embedding": _embed(chunk),
        })
    _save_vector_index(records)


def save_transcript(text: str, meta: Dict[str, Any] = None) -> str:
    tid = str(uuid.uuid4())
    rec = {
        "id": tid,
        "text": text,
        "meta": meta or {},
    }
    _write_json(os.path.join(TRANSCRIPT_DIR, f"{tid}.json"), rec)
    _index_content(tid, "transcript", text, rec["meta"])
    return tid


def get_transcript(tid: str) -> Dict[str, Any]:
    path = os.path.join(TRANSCRIPT_DIR, f"{tid}.json")
    return _read_json(path)


def save_summary(tid: str, summary: str) -> None:
    rec = {"transcript_id": tid, "summary": summary}
    _write_json(os.path.join(SUMMARY_DIR, f"{tid}.json"), rec)
    _index_content(tid, "summary", summary, get_transcript(tid).get("meta", {}))


def get_summary(tid: str) -> Dict[str, Any]:
    path = os.path.join(SUMMARY_DIR, f"{tid}.json")
    return _read_json(path)


def save_actions(tid: str, actions: List[Dict[str, Any]]) -> None:
    rec = {"transcript_id": tid, "actions": actions}
    _write_json(os.path.join(ACTIONS_DIR, f"{tid}.json"), rec)
    action_text = "\n".join(
        " ".join(str(action.get(field) or "") for field in ("task", "owner", "deadline", "source"))
        for action in actions
    )
    _index_content(tid, "action_items", action_text, get_transcript(tid).get("meta", {}))


def get_actions(tid: str) -> Dict[str, Any]:
    path = os.path.join(ACTIONS_DIR, f"{tid}.json")
    return _read_json(path)


def list_transcripts() -> List[str]:
    return [f[:-5] for f in os.listdir(TRANSCRIPT_DIR) if f.endswith('.json')]

def search_transcripts(query: str, top_k: int = 5) -> List[str]:
    hits = retrieve_passages(query, top_k=top_k)
    return list(dict.fromkeys(hit["transcript_id"] for hit in hits))


def retrieve_passages(query: str, top_k: int = 5) -> List[Dict[str, Any]]:
    """Return cosine-ranked transcript, summary, and action-item chunks for RAG."""
    query_vector = _embed(query)
    if not any(query_vector):
        return []
    matches = []
    for record in _load_vector_index():
        embedding = record.get("embedding", [])
        if len(embedding) != len(query_vector):
            continue
        score = sum(left * right for left, right in zip(query_vector, embedding))
        if score > 0:
            matches.append({
                "transcript_id": record["transcript_id"],
                "meta": record.get("meta", {}),
                "passage": record["text"],
                "content_type": record.get("content_type", "transcript"),
                "chunk": record.get("chunk", 1),
                "score": score,
            })
    matches.sort(key=lambda match: match["score"], reverse=True)
    return matches[:top_k]


def ensure_vector_index() -> None:
    """Backfill vectors for records created before vector retrieval was introduced."""
    existing = _load_vector_index()
    indexed = {(record.get("transcript_id"), record.get("content_type")) for record in existing}
    for transcript_id in list_transcripts():
        transcript = get_transcript(transcript_id)
        if (transcript_id, "transcript") not in indexed:
            _index_content(transcript_id, "transcript", transcript.get("text", ""), transcript.get("meta", {}))
        if (transcript_id, "summary") not in indexed:
            try:
                save_summary(transcript_id, get_summary(transcript_id).get("summary", ""))
            except FileNotFoundError:
                pass
        if (transcript_id, "action_items") not in indexed:
            try:
                save_actions(transcript_id, get_actions(transcript_id).get("actions", []))
            except FileNotFoundError:
                pass
