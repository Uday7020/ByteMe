"""Streamlit interface for the FastAPI meeting summarizer backend."""
import requests
import streamlit as st


st.set_page_config(page_title="Meeting Summarizer", page_icon="📝", layout="wide")
st.title("AI Meeting Summarizer & Action Tracker")

api_url = st.sidebar.text_input("FastAPI URL", "http://127.0.0.1:8000").rstrip("/")
st.sidebar.caption("Start the API first: `uvicorn app:app --reload`")


def call_api(method, path, **kwargs):
    try:
        # The first local Whisper use may need time to download and initialize a model.
        response = requests.request(method, f"{api_url}{path}", timeout=300, **kwargs)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as exc:
        detail = None
        if exc.response is not None:
            try:
                detail = exc.response.json().get("detail")
            except ValueError:
                pass
        st.error(detail or f"API request failed: {exc}")
        return None


summary_tab, tracker_tab, qa_tab = st.tabs(["Summarize meeting", "Action tracker", "Ask past meetings"])

with summary_tab:
    st.subheader("Meeting audio")
    uploaded_audio = st.file_uploader("Upload an audio file", type=["wav", "mp3", "m4a", "mp4", "webm", "ogg"])
    model = st.selectbox("Speech-to-text model", ["tiny", "base"], index=0)
    st.caption("Transcription runs locally. The selected model downloads once to .whisper_models.")
    if uploaded_audio and st.button("Transcribe audio"):
        with st.spinner("Transcribing the recording… the model may download on its first use."):
            transcript_result = call_api(
                "POST",
                "/transcribe",
                files={"file": (uploaded_audio.name, uploaded_audio.getvalue(), uploaded_audio.type)},
                data={"model": model},
            )
        if transcript_result:
            st.session_state["transcript_text"] = transcript_result["text"]
            st.success(f"Transcribed in {transcript_result['language']} using the {transcript_result['model']} model.")

    st.subheader("Meeting transcript")
    transcript = st.text_area(
        "Paste a meeting transcript",
        height=260,
        placeholder="Alice: I will share the proposal by Friday.\nBob: We should review the budget next week.",
        key="transcript_text",
    )
    if st.button("Analyze meeting", type="primary"):
        if not transcript.strip():
            st.warning("Paste a transcript before analyzing it.")
        else:
            ingested = call_api("POST", "/ingest", json={"text": transcript})
            if ingested:
                transcript_id = ingested["transcript_id"]
                summary = call_api("POST", "/summarize", json={"transcript_id": transcript_id})
                action_items = call_api("POST", "/extract_actions", json={"transcript_id": transcript_id})
                st.session_state["transcript_id"] = transcript_id
                if summary:
                    st.subheader("Summary")
                    st.write(summary["summary"])
                if action_items:
                    st.subheader("Action items")
                    st.dataframe(action_items["actions"], use_container_width=True)
    if st.session_state.get("transcript_id") and st.button("Add latest action items to tracker"):
        tracked = call_api("POST", "/track", json={"transcript_id": st.session_state["transcript_id"]})
        if tracked is not None:
            st.success(f"Added {len(tracked['created_action_ids'])} action item(s) to the tracker.")

with tracker_tab:
    if st.button("Load action items"):
        listing = call_api("GET", "/track/list")
        if listing is not None:
            st.dataframe(listing["actions"], use_container_width=True)

with qa_tab:
    st.subheader("Follow-up Q&A")
    st.caption("Ask about information in previously analyzed meetings. Answers are grounded in retrieved transcript excerpts.")
    question = st.text_input("Ask a question", placeholder="What did we decide about the product launch?")
    if st.button("Ask meetings", type="primary"):
        if not question.strip():
            st.warning("Enter a question first.")
        else:
            with st.spinner("Searching past meetings..."):
                result = call_api("POST", "/ask", json={"question": question})
            if result:
                st.subheader("Answer")
                st.write(result["answer"])
                if result["sources"]:
                    with st.expander("View supporting meeting excerpts"):
                        for source in result["sources"]:
                            st.markdown(f"**Source {source['source']} — meeting `{source['transcript_id']}`**")
                            st.write(source["excerpt"])
