"""Streamlit interface for the FastAPI meeting summarizer backend."""
import requests
import streamlit as st


st.set_page_config(page_title="Meeting Summarizer", page_icon="📝", layout="wide")
st.title("AI Meeting Summarizer & Action Tracker")

api_url = st.sidebar.text_input("FastAPI URL", "http://127.0.0.1:8000").rstrip("/")
st.sidebar.caption("Start the API first: `uvicorn app:app --reload`")


def call_api(method, path, **kwargs):
    try:
        response = requests.request(method, f"{api_url}{path}", timeout=30, **kwargs)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as exc:
        st.error(f"API request failed: {exc}")
        return None


summary_tab, tracker_tab = st.tabs(["Summarize meeting", "Action tracker"])

with summary_tab:
    st.subheader("Meeting recording")
    audio = st.audio_input("Record audio", key="meeting_audio")
    uploaded_audio = st.file_uploader("Or upload an audio file", type=["wav", "mp3", "m4a", "mp4", "webm", "ogg"])
    recording = audio or uploaded_audio
    model = st.selectbox("Speech-to-text model", ["base", "tiny", "small", "medium", "large-v3"], index=0)
    if recording and st.button("Transcribe recording"):
        with st.spinner("Transcribing the recording… the model may download on its first use."):
            transcript_result = call_api(
                "POST",
                "/transcribe",
                files={"file": (recording.name, recording.getvalue(), recording.type)},
                data={"model": model},
            )
        if transcript_result:
            st.session_state["transcript_text"] = transcript_result["text"]
            st.success(f"Transcribed in {transcript_result['language']} using the {transcript_result['model']} model.")

    st.subheader("Meeting transcript")
    transcript = st.text_area(
        "Paste a meeting transcript",
        height=260,
        placeholder="Alice: I will share the proposal by Friday.\nBob: We should review the budget next week.",
        key="transcript_text",
    )
    if st.button("Analyze meeting", type="primary"):
        if not transcript.strip():
            st.warning("Paste a transcript before analyzing it.")
        else:
            ingested = call_api("POST", "/ingest", json={"text": transcript})
            if ingested:
                transcript_id = ingested["transcript_id"]
                summary = call_api("POST", "/summarize", json={"transcript_id": transcript_id})
                action_items = call_api("POST", "/extract_actions", json={"transcript_id": transcript_id})
                st.session_state["transcript_id"] = transcript_id
                if summary:
                    st.subheader("Summary")
                    st.write(summary["summary"])
                if action_items:
                    st.subheader("Action items")
                    st.dataframe(action_items["actions"], use_container_width=True)
    if st.session_state.get("transcript_id") and st.button("Add latest action items to tracker"):
        tracked = call_api("POST", "/track", json={"transcript_id": st.session_state["transcript_id"]})
        if tracked is not None:
            st.success(f"Added {len(tracked['created_action_ids'])} action item(s) to the tracker.")

with tracker_tab:
    if st.button("Load action items"):
        listing = call_api("GET", "/track/list")
        if listing is not None:
            st.dataframe(listing["actions"], use_container_width=True)
