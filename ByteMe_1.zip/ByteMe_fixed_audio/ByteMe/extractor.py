"""
Heuristic action-item extractor.
Extracts structured items with fields: task, owner (optional), deadline (optional), source_sentence.
Replace with an LLM prompt or an extraction model for higher precision.
"""
import re
from typing import List, Dict
from dateutil import parser as dateparser

OWNER_HINTS = ["assigned to", "assign to", "owner", "I will", "I'll", "I'll", "I can", "we will", "we'll", "will"]
DEADLINE_HINTS = ["by ", "on ", "due ", "next ", "target ", "deadline"]


def _parse_deadline(sent: str):
    # try to extract a date-like phrase using dateutil
    # This is a best-effort parser: returns ISO date string when parseable
    for m in re.finditer(r"(by|on|due|before|after) ([A-Za-z0-9 ,.-]+)", sent, flags=re.I):
        phrase = m.group(2)
        try:
            dt = dateparser.parse(phrase, fuzzy=True)
            return dt.date().isoformat()
        except Exception:
            continue
    # fallback: look for month/day words
    try:
        dt = dateparser.parse(sent, fuzzy=True)
        return dt.date().isoformat()
    except Exception:
        return None


def extract_actions(text: str) -> List[Dict]:
    sents = re.split(r'(?<=[.!?])\s+', text.strip())
    actions = []
    for sent in sents:
        lower = sent.lower()
        if any(k in lower for k in ["action", "todo", "assign", "assign to", "will", "i will", "we will", "should"]):
            # attempt to find owner
            owner = None
            for hint in ["assigned to", "assign to", "owner is", "owner:"]:
                m = re.search(hint + r"\s+([A-Z][a-zA-Z0-9_\-]+)", sent, flags=re.I)
                if m:
                    owner = m.group(1)
                    break
            # heuristic: look for named speaker like "Alice: ..." at start
            m2 = re.match(r"^([A-Z][a-z]+):\s+(.+)", sent)
            if m2:
                # If the speaker says "I will ..." treat speaker as owner
                speaker, sbody = m2.group(1), m2.group(2)
                if re.search(r"\b(i will|i'll|i can|i will|i'll|i can)\b", sbody, flags=re.I):
                    owner = speaker
            deadline = _parse_deadline(sent)
            task = sent.strip()
            actions.append({"task": task, "owner": owner, "deadline": deadline, "source": sent})
    # Additional pass: lines beginning with TODO or Action:
    for line in text.splitlines():
        if line.strip().lower().startswith('todo') or line.strip().lower().startswith('action'):
            content = line.split(':', 1)[-1].strip()
            if content:
                actions.append({"task": content, "owner": None, "deadline": None, "source": line})
    # Deduplicate by source
    seen = set()
    unique = []
    for a in actions:
        key = a.get('source')
        if key not in seen:
            seen.add(key)
            unique.append(a)
    return unique
