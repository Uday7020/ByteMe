"""Helpers for the record-audio-to-summary workflow used by the Streamlit app."""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional


def analyze_transcript(
    transcript_text: str,
    api_client: Optional[Callable[..., Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Ingest a transcript, generate a summary, and extract action items.

    Parameters
    ----------
    transcript_text:
        The meeting transcript text to analyze.
    api_client:
        Callable supporting ``(method, path, **kwargs)`` and returning JSON data.
    """
    if not transcript_text or not transcript_text.strip():
        raise ValueError("Transcript text is required before analysis.")

    if api_client is None:
        raise ValueError("An API client is required to analyze the transcript.")

    ingested = api_client("POST", "/ingest", json={"text": transcript_text})
    if ingested is None:
        raise RuntimeError("The transcript could not be ingested.")

    transcript_id = ingested["transcript_id"]
    summary_result = api_client("POST", "/summarize", json={"transcript_id": transcript_id})
    action_result = api_client("POST", "/extract_actions", json={"transcript_id": transcript_id})

    return {
        "transcript_id": transcript_id,
        "summary": summary_result.get("summary") if summary_result else None,
        "actions": action_result.get("actions", []) if action_result else [],
        "summary_result": summary_result,
        "action_items_result": action_result,
    }
