"""Local speech-to-text support powered by faster-whisper.

Models are downloaded automatically by faster-whisper the first time they are used.
"""
from pathlib import Path
from typing import Dict


def transcribe(audio_path: Path, model_size: str = "base") -> Dict[str, str]:
    """Transcribe an audio file and return the recognized text and language."""
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError(
            "Speech-to-text is not installed. Run: pip install -r requirements.txt"
        ) from exc

    model = WhisperModel(model_size, device="cpu", compute_type="int8")
    segments, info = model.transcribe(str(audio_path), beam_size=5, vad_filter=True)
    text = " ".join(segment.text.strip() for segment in segments).strip()
    return {"text": text, "language": info.language, "model": model_size}
