"""Streamlit interface for the FastAPI meeting summarizer backend."""
import requests
import streamlit as st

from meeting_workflow import analyze_transcript


st.set_page_config(page_title="Meeting Summarizer", page_icon="📝", layout="wide")
st.title("AI Meeting Summarizer & Action Tracker")

api_url = st.sidebar.text_input("FastAPI URL", "http://127.0.0.1:8000").rstrip("/")
st.sidebar.caption("Start the API first: `uvicorn app:app --reload`")


def call_api(method, path, **kwargs):
    try:
        response = requests.request(method, f"{api_url}{path}", timeout=300, **kwargs)
        response.raise_for_status()
        return response.json()
    except requests.HTTPError as exc:
        detail = exc.response.text if exc.response is not None else str(exc)
        st.error(f"API request failed ({exc.response.status_code if exc.response is not None else 'unknown'}): {detail}")
        return None
    except requests.RequestException as exc:
        st.error(f"API request failed: {exc}")
        return None


summary_tab, tracker_tab = st.tabs(["Summarize meeting", "Action tracker"])

with summary_tab:
    st.subheader("Upload meeting audio")
    uploaded_audio = st.file_uploader("Upload an audio file", type=["wav", "mp3", "m4a", "mp4", "webm", "ogg"])
    model = st.selectbox("Speech-to-text model", ["base", "tiny", "small", "medium", "large-v3"], index=0)
    if uploaded_audio and st.button("Transcribe audio"):
        with st.spinner("Transcribing the audio… the model may download on its first use."):
            transcript_result = call_api(
                "POST",
                "/transcribe",
                files={"file": (uploaded_audio.name, uploaded_audio.getvalue(), uploaded_audio.type)},
                data={"model": model},
            )
        if transcript_result:
            st.session_state["transcript_text"] = transcript_result["text"]
            st.success(f"Transcribed in {transcript_result['language']} using the {transcript_result['model']} model.")
            st.session_state["transcript_id"] = None
            if st.button("Generate summary from this audio", type="primary"):
                with st.spinner("Generating summary and action items…"):
                    result = analyze_transcript(transcript_result["text"], call_api)
                    st.session_state["transcript_id"] = result["transcript_id"]
                    if result["summary"]:
                        st.subheader("Summary")
                        st.write(result["summary"])
                    if result["actions"]:
                        st.subheader("Action items")
                        st.dataframe(result["actions"], use_container_width=True)

    st.subheader("Meeting transcript")
    transcript = st.text_area(
        "Paste a meeting transcript",
        height=260,
        placeholder="Alice: I will share the proposal by Friday.\nBob: We should review the budget next week.",
        key="transcript_text",
    )
    if st.button("Analyze meeting", type="primary"):
        if not transcript.strip():
            st.warning("Paste a transcript before analyzing it.")
        else:
            result = analyze_transcript(transcript, call_api)
            if result:
                st.session_state["transcript_id"] = result["transcript_id"]
                if result["summary"]:
                    st.subheader("Summary")
                    st.write(result["summary"])
                if result["actions"]:
                    st.subheader("Action items")
                    st.dataframe(result["actions"], use_container_width=True)
    if st.session_state.get("transcript_id") and st.button("Add latest action items to tracker"):
        tracked = call_api("POST", "/track", json={"transcript_id": st.session_state["transcript_id"]})
        if tracked is not None:
            st.success(f"Added {len(tracked['created_action_ids'])} action item(s) to the tracker.")

with tracker_tab:
    if st.button("Load action items"):
        listing = call_api("GET", "/track/list")
        if listing is not None:
            st.dataframe(listing["actions"], use_container_width=True)
