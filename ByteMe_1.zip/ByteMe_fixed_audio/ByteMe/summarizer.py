"""
Simple summarizer heuristics. This is a placeholder — replace with LLM calls for production.
Provides a summarize_text function that returns a concise summary from a transcript.
"""
from typing import List
import re

try:
    import nltk
    nltk.data.find('tokenizers/punkt')
except Exception:
    # nltk may not be installed — sentence splitting fallback
    pass


def _split_sentences(text: str) -> List[str]:
    try:
        import nltk
        return nltk.sent_tokenize(text)
    except Exception:
        # very simple fallback
        return re.split(r'(?<=[.!?])\s+', text.strip())


def summarize_text(text: str, max_sentences: int = 5) -> str:
    """Return a concise summary using naive heuristics.

    - Picks top sentences by keyword coverage of nouns/verbs and position.
    - For production, call an LLM or summarization model here.
    """
    sents = _split_sentences(text)
    if len(sents) <= max_sentences:
        return "\n".join(sents)

    # Score sentences by length and presence of action words
    keywords = set(["decide", "decided", "action", "agree", "deadline", "due", "will", "should", "assign", "owner", "target", "deliver", "complete"])
    def score(sent: str):
        s = 0
        s += min(len(sent.split()), 40) / 40
        lw = set(w.strip('.,').lower() for w in sent.split())
        s += len(lw & keywords)
        # position boost for opening sentences
        if sents.index(sent) == 0:
            s += 0.5
        return s

    ranked = sorted(sents, key=score, reverse=True)
    chosen = ranked[:max_sentences]
    # Preserve original order
    chosen_sorted = sorted(chosen, key=lambda x: sents.index(x))
    return "\n".join(chosen_sorted)


# Simple evaluation hook: compare summary length
def evaluate_summary(summary: str, transcript: str) -> dict:
    # returns a small dict that a SME can inspect
    return {"summary_len": len(summary.split()), "transcript_len": len(transcript.split())}
