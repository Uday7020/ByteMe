from meeting_workflow import analyze_transcript


class FakeAPI:
    def __init__(self):
        self.calls = []

    def __call__(self, method, path, **kwargs):
        self.calls.append((method, path, kwargs))
        if path == "/ingest":
            return {"transcript_id": "abc123"}
        if path == "/summarize":
            return {"summary": "Summary text"}
        if path == "/extract_actions":
            return {"actions": [{"task": "Send update", "owner": "Sam"}]}
        raise AssertionError(f"Unexpected path: {path}")


def test_analyze_transcript_returns_summary_and_actions():
    api = FakeAPI()

    result = analyze_transcript("Alice: We need to ship by Friday.", api)

    assert result["transcript_id"] == "abc123"
    assert result["summary"] == "Summary text"
    assert result["actions"][0]["task"] == "Send update"
    assert [call[1] for call in api.calls] == ["/ingest", "/summarize", "/extract_actions"]
